//
//  MovieTrending1MovieTrending1Initializer.swift
//  viperers
//
//  Created by generamba setup on 04/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

class MovieTrending1ModuleInitializer: NSObject {

    //Connect with object on storyboard
    @IBOutlet weak var movietrending1ViewController: MovieTrending1ViewController!

    override func awakeFromNib() {

        let configurator = MovieTrending1ModuleConfigurator()
        configurator.configureModuleForViewInput(viewInput: movietrending1ViewController)
    }

}
