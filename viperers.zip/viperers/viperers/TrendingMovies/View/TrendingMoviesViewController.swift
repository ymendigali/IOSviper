//
//  TrendingMoviesTrendingMoviesViewController.swift
//  viperers
//
//  Created by generamba setup on 05/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

class TrendingMoviesViewController: UIViewController {

    var output: TrendingMoviesViewOutput!

    @IBOutlet weak var tableView: UITableView!

    private var movies: [TrendingMoviesEntity.Movie] = [TrendingMoviesEntity.Movie](){
        didSet{
            isLoading = false
            tableView.reloadData()
        }
    }
    
    private var pageNumber: Int = 1
    private var isLoading: Bool = false

    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.register(UINib(nibName: TableViewCell.identifier, bundle: nil), forCellReuseIdentifier: TableViewCell.identifier)
        output.getTrendingMovies(pageNumber)
    }
    



    
}
extension TrendingMoviesViewController: TrendingMoviesViewInput{
    func setTrendingMovies(_ movies: [TrendingMoviesEntity.Movie]) {
        self.movies = movies
    }
    
    func setupInitialState() {
    }
    
    func getController() -> UIViewController {
        return self
    }

}

extension TrendingMoviesViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let movieId = movies[indexPath.row].id
        output?.openMovieDetails(with: movieId)
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentOffSet = scrollView.contentOffset.y
        let maximumOffSet = scrollView.contentSize.height - scrollView.frame.height
        let deltaOffSet = maximumOffSet - currentOffSet
        if deltaOffSet <= 10 && currentOffSet > 200 && !isLoading{
            isLoading = true
            pageNumber+=1
            output.getTrendingMovies(pageNumber)
        }
        
    }
}
extension TrendingMoviesViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: TableViewCell.identifier, for: indexPath) as! TableViewCell
        cell.movie = movies[indexPath.row]
        return cell
    }
}

