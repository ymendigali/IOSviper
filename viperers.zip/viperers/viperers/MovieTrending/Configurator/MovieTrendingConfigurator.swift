//
//  MovieTrendingMovieTrendingConfigurator.swift
//  viperers
//
//  Created by generamba setup on 04/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

class MovieTrendingModuleConfigurator {

    func configureModuleForViewInput<UIViewController>(viewInput: UIViewController) {

        if let viewController = viewInput as? MovieTrendingViewController {
            configure(viewController: viewController)
        }
    }

    private func configure(viewController: MovieTrendingViewController) {

        let router = MovieTrendingRouter()

        let presenter = MovieTrendingPresenter()
        presenter.view = viewController
        presenter.router = router

        let interactor = MovieTrendingInteractor()
        interactor.output = presenter

        presenter.interactor = interactor
        viewController.output = presenter
    }

}
