//
//  MovieTrendingMovieTrendingPresenter.swift
//  viperers
//
//  Created by generamba setup on 04/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

class MovieTrendingPresenter: MovieTrendingModuleInput, MovieTrendingViewOutput, MovieTrendingInteractorOutput {

    weak var view: MovieTrendingViewInput!
    var interactor: MovieTrendingInteractorInput!
    var router: MovieTrendingRouterInput!

    func viewIsReady() {

    }
}
