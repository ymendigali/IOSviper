//
//  MovieTrending1MovieTrending1Configurator.swift
//  viperers
//
//  Created by generamba setup on 04/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

class MovieTrending1ModuleConfigurator {

    func configureModuleForViewInput<UIViewController>(viewInput: UIViewController) {

        if let viewController = viewInput as? MovieTrending1ViewController {
            configure(viewController: viewController)
        }
    }

    private func configure(viewController: MovieTrending1ViewController) {

        let router = MovieTrending1Router()

        let presenter = MovieTrending1Presenter()
        presenter.view = viewController
        presenter.router = router

        let interactor = MovieTrending1Interactor()
        interactor.output = presenter

        presenter.interactor = interactor
        viewController.output = presenter
    }

}
