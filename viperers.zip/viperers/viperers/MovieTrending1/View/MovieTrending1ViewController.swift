//
//  MovieTrending1MovieTrending1ViewController.swift
//  viperers
//
//  Created by generamba setup on 04/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

class MovieTrending1ViewController: UIViewController, MovieTrending1ViewInput {

    var output: MovieTrending1ViewOutput!

    // MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        output.viewIsReady()
    }


    // MARK: MovieTrending1ViewInput
    func setupInitialState() {
    }
}
