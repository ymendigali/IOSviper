//
//  HomeHomeViewController.swift
//  viperers
//
//  Created by generamba setup on 05/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, HomeViewInput {

    var output: HomeViewOutput!
    @IBOutlet weak var cinemaCV: UICollectionView!
    
    @IBOutlet weak var trendingCV: UICollectionView!
    @IBOutlet weak var comingSoonCV: UICollectionView!
    // MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        output.viewIsReady()
        
        configureView()
    }
    func configureView(){
        cinemaCV.contentInset = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 0)
        cinemaCV.delegate = self
        cinemaCV.dataSource = self
        cinemaCV.register(UINib(nibName: MovieCVCell.identifier, bundle: Bundle(for: MovieCVCell.self)), forCellWithReuseIdentifier: MovieCVCell.identifier)
        comingSoonCV.contentInset = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 0)
        comingSoonCV.delegate = self
        comingSoonCV.dataSource = self
        comingSoonCV.register(UINib(nibName: MovieCVCell.identifier, bundle: Bundle(for: MovieCVCell.self)), forCellWithReuseIdentifier: MovieCVCell.identifier)
        trendingCV.contentInset = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 0)
        trendingCV.delegate = self
        trendingCV.dataSource = self
        trendingCV.register(UINib(nibName: MovieCVCell.identifier, bundle: Bundle(for: MovieCVCell.self)), forCellWithReuseIdentifier: MovieCVCell.identifier)
    }

    // MARK: HomeViewInput
    func setupInitialState() {
    }
}

extension HomeViewController: UICollectionViewDelegate, UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == cinemaCV{
            return 1
        }else if collectionView == comingSoonCV{
            return 10
        }else{
            return 2
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == cinemaCV{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MovieCVCell.identifier, for: indexPath) as! MovieCVCell
            cell.backgroundColor = .white
            return cell
        }else if collectionView == comingSoonCV{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MovieCVCell.identifier, for: indexPath) as! MovieCVCell
            cell.backgroundColor = .white
            return cell
        }else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MovieCVCell.identifier, for: indexPath) as! MovieCVCell
            cell.backgroundColor = .white
            return cell
        }
    }
}

extension HomeViewController: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize (width: 120, height: 224)
    }
}
