//
//  MovieTrending1MovieTrending1Presenter.swift
//  viperers
//
//  Created by generamba setup on 04/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

class MovieTrending1Presenter: MovieTrending1ModuleInput, MovieTrending1ViewOutput, MovieTrending1InteractorOutput {
    func viewIsReady() {
        
    }
    

    weak var view: MovieTrending1ViewInput!
    var interactor: MovieTrending1InteractorInput!
    var router: MovieTrending1RouterInput!

}

extension MovieTrendingPresenter: MovieTrending1ViewOutput{
    func getMovieTrending(_ pageNumber: Int) {
        interactor?.getMovieTrending(pageNumber)
    }
}

extension MovieTrendingPresenter: MovieTrending1InteractorOutput{
    func setTren(_ movies: [MovieTrendingEntity.Movie]) {
        view?.setMovieTrending(movies)
    }
}
