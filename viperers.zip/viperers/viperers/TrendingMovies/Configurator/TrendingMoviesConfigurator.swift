//
//  TrendingMoviesTrendingMoviesConfigurator.swift
//  viperers
//
//  Created by generamba setup on 05/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

class TrendingMoviesModuleConfigurator {

    func configureModuleForViewInput<UIViewController>(viewInput: UIViewController) {

        if let viewController = viewInput as? TrendingMoviesViewController {
            configure(viewController: viewController)
        }
    }

    private func configure(viewController: TrendingMoviesViewController) {

        let router = TrendingMoviesRouter()

        let presenter = TrendingMoviesPresenter()
        presenter.view = viewController
        presenter.router = router

        let interactor = TrendingMoviesInteractor()
        interactor.output = presenter

        presenter.interactor = interactor
        viewController.output = presenter
    }

}
