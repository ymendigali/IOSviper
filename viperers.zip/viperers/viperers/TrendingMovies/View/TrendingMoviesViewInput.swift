//
//  TrendingMoviesTrendingMoviesViewInput.swift
//  viperers
//
//  Created by generamba setup on 05/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

protocol TrendingMoviesViewInput: class {

    /**
        @author generamba setup
        Setup initial state of the view
    */

    func setupInitialState()
    
    func setTrendingMovies(_ movies: [TrendingMoviesEntity.Movie])
    
    func getController() -> UIViewController
}
