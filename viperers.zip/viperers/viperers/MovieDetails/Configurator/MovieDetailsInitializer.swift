//
//  MovieDetailsMovieDetailsInitializer.swift
//  viperers
//
//  Created by generamba setup on 05/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

class MovieDetailsModuleInitializer: NSObject {

    func viewConntroller( movieId: Int) -> UIViewController{
        let vc = getVCFromStoryboard()
        let configurator = MovieDetailsModuleConfigurator()
        configurator.configureModuleForViewInput(viewInput: vc, movieId: movieId)
        return vc
    }
    
    private func getVCFromStoryboard() -> MovieDetailsViewController{
        let storyboard = UIStoryboard( name: "MovieDetails", bundle: Bundle.main)
        let vc = storyboard.instantiateViewController(identifier: "MovieDetailsViewController") as! MovieDetailsViewController
        
        return vc
        
    }

}
