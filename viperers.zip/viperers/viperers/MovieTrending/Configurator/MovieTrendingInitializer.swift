//
//  MovieTrendingMovieTrendingInitializer.swift
//  viperers
//
//  Created by generamba setup on 04/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

class MovieTrendingModuleInitializer: NSObject {

    //Connect with object on storyboard
    @IBOutlet weak var movietrendingViewController: MovieTrendingViewController!

    override func awakeFromNib() {

        let configurator = MovieTrendingModuleConfigurator()
        configurator.configureModuleForViewInput(viewInput: movietrendingViewController)
    }

}
