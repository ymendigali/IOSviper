//
//  MovieDetailsMovieDetailsViewController.swift
//  viperers
//
//  Created by generamba setup on 05/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

class MovieDetailsViewController: UIViewController, MovieDetailsViewInput {
    

    @IBOutlet weak var movieDescription: UILabel!
    @IBOutlet weak var movieDate: UILabel!
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var containerRating: UIView!
    var output: MovieDetailsViewOutput!

    // MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        output.viewIsReady()
        containerRating.layer.cornerRadius = 20
        containerRating.layer.masksToBounds = true

    }


    // MARK: MovieDetailsViewInput
    func setupInitialState(id: Int) {
    }
}
