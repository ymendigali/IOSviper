//
//  MovieEntity.swift
//  CoreData
//
//  Created by Yersultan Mendigali on 22.05.2021.
//

import Foundation

struct MovieDetailsEntity: Decodable {
    var id: Int?
    let poster: String?
    let title: String
    let releaseDate: String
    let rating: Double?
    let description: String
    
    
    enum CodingKeys: String, CodingKey {
        case poster = "poster_path"
        case title = "original_title"
        case releaseDate = "release_date"
        case rating = "vote_average"
        case description = "overview"
        
        }
}
