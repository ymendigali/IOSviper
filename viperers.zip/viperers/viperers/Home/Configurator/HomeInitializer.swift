//
//  HomeHomeInitializer.swift
//  viperers
//
//  Created by generamba setup on 05/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

class HomeModuleInitializer: NSObject {

    func viewConntroller() -> UIViewController{
        let vc = getVCFromStoryboard()
        let configurator = HomeModuleConfigurator()
        configurator.configureModuleForViewInput(viewInput: vc)
        return vc
    }
    
    private func getVCFromStoryboard() -> HomeViewController{
        let storyboard = UIStoryboard( name: "Home", bundle: Bundle.main)
        let vc = storyboard.instantiateViewController(identifier: "HomeViewController") as! HomeViewController
        
        return vc
        
    }

}
