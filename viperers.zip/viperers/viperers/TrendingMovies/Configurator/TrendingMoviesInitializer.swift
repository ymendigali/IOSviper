//
//  TrendingMoviesTrendingMoviesInitializer.swift
//  viperers
//
//  Created by generamba setup on 05/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import UIKit

class TrendingMoviesModuleInitializer: NSObject {

    func viewConntroller() -> UIViewController{
        let vc = getVCFromStoryboard()
        let configurator = TrendingMoviesModuleConfigurator()
        configurator.configureModuleForViewInput(viewInput: vc)
        return vc
    }
    
     func getVCFromStoryboard() -> TrendingMoviesViewController{
        let storyboard = UIStoryboard( name: "TrendingMoviesStoryboard", bundle: Bundle.main)
        let vc = storyboard.instantiateViewController(identifier: "TrendingMoviesViewController") as! TrendingMoviesViewController
        
        return vc
        
    }


}
