//
//  MovieDetailsMovieDetailsModuleInput.swift
//  viperers
//
//  Created by generamba setup on 05/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

protocol MovieDetailsModuleInput: class {

}
