//
//  TrendingMoviesTrendingMoviesInteractor.swift
//  viperers
//
//  Created by generamba setup on 05/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

import Foundation

class TrendingMoviesInteractor {

    weak var output: TrendingMoviesInteractorOutput!

}

extension TrendingMoviesInteractor: TrendingMoviesInteractorInput{
    func getTrendingMovies(_ pageNumber: Int) {
        var urlComponent = URLComponents(string: "https://api.themoviedb.org/3/trending/movie/week")
        urlComponent?.queryItems = [
            URLQueryItem(name: "api_key", value: "4f02196edbf94fa32ed2e913d93e4d42"),
            URLQueryItem(name: "page", value: "\(pageNumber)")
        ]
        
        if let url = urlComponent?.url?.absoluteURL{
            URLSession.shared.dataTask(with: url) { [weak self] (data, response, error) in
                if error == nil {
                    DispatchQueue.global().async {
                        do{
                            if let data = data{
                                let movies = try JSONDecoder().decode(TrendingMoviesEntity.self, from: data)
                                DispatchQueue.main.async {
                                    self?.output.setTrendingMovies(movies.movies)
                                }
                            }
                        }catch{
                            print(error)
                        }
                    }
                }
            }.resume()
        }
    }
}
