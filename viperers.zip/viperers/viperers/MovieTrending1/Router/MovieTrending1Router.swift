//
//  MovieTrending1MovieTrending1Router.swift
//  viperers
//
//  Created by generamba setup on 04/06/2021.
//  Copyright © 2021 IOS Developer. All rights reserved.
//

class MovieTrending1Router: MovieTrending1RouterInput {

}
