//
//  MovieCVCell.swift
//  viperers
//
//  Created by Yersultan Mendigali on 05.06.2021.
//

import UIKit

class MovieCVCell: UICollectionViewCell {
    
    public static let identifier: String = "MovieCVCell"
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
