//
//  TableViewCell.swift
//  viperers
//
//  Created by Yersultan Mendigali on 05.06.2021.
//

import UIKit
//import Kingfisher


class TableViewCell: UITableViewCell {

    public static let identifier: String = "TableViewCell"
    
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var containerRatiingView: UIView!
    @IBOutlet weak var movieDateLabel: UILabel!
    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var movieTitleLabel: UILabel!
    
    public var movie: TrendingMoviesEntity.Movie?{
        didSet{
            if let movie = movie{
                let posterURL = URL(string: "https://image.tmdb.org/t/p/w500" + (movie.poster ?? ""))
               // posterImageView.kf.setImage(with: posterURL)
                movieTitleLabel.text = movie.title
                ratingLabel.text = "\(String(describing: movie.rating))"
                movieDateLabel.text = movie.releaseDate
           }
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        posterImageView.layer.cornerRadius = 12
        posterImageView.layer.masksToBounds = true
        containerRatiingView.layer.cornerRadius = 20
        containerRatiingView.layer.masksToBounds = true
        
    }
    
}
